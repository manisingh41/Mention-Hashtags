

import Foundation
import UIKit
struct FontDetails {
    var color: UIColor
    var size: Double
    var style: String
    var font: UIFont
    init(codingDict: [String: Any]) {
        guard
            let color = codingDict["color"] as? String,
            let size = codingDict["size"] as? Double,
            let opacity = codingDict["opacity"] as? Double,
            let style = codingDict["style"] as? String
            else {
                self.color = .white
                self.size = 20.0
                self.style = "Regular"
                self.font = UIFont.systemFont(ofSize: CGFloat(self.size))
                return
        }
        self.color = color.hexStringToUIColor(opacity: CGFloat(opacity))
        self.size = size
        self.style = style
        switch style {
        case "Bold":
            self.font = UIFont.systemFont(ofSize: CGFloat(size), weight: .bold)
        default:
            self.font = UIFont.systemFont(ofSize: CGFloat(size), weight: .regular)
        }
    }
}
let fc1 = FontDetails.init(codingDict: ["color": "fafafa", "size": 20.0, "opacity": 1.0, "style": "Regular"])
let fc2 = FontDetails.init(codingDict: ["color": "fafafa", "size": 15.0, "opacity": 1.0, "style": "Regular"])
let fc3 = FontDetails.init(codingDict: ["color": "fafafa", "size": 15.0, "opacity": 0.4, "style": "Regular"])
let fc6 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.2, "style": "Regular"])
let fc7 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Regular"])
let fc8 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.6, "style": "Regular"])
let fc9 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Bold"])
let fc10 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 16.0, "opacity": 1.0, "style": "Bold"])
let fc11 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 16.0, "opacity": 1.0, "style": "Regular"])
let fc12 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.6, "style": "Regular"])
let fc13 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.4, "style": "Regular"])
let fc14 = FontDetails.init(codingDict: ["color": "7f7f7f", "size": 12.0, "opacity": 1.0, "style": "Regular"])
let fc15 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.8, "style": "Regular"])
let fc16 = FontDetails.init(codingDict: ["color": "fafafa", "size": 18.0, "opacity": 1.0, "style": "Regular"])
let fc17 = FontDetails.init(codingDict: ["color": "000000", "size": 17.0, "opacity": 0.8, "style": "Regular"])
let fr3 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.9, "style": "Regular"])
let ft9 = FontDetails.init(codingDict: ["color": "000000", "size": 16.5, "opacity": 0.9, "style": "Medium"])
let fc53 = FontDetails.init(codingDict: ["color": "518cdb", "size": 14.0, "opacity": 0.8, "style": "Bold"])
let fw2 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 12.0, "opacity": 1.0, "style": "Regular"])
let fw3 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.4, "style": "Regular"])
let fc31 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 14.0, "opacity": 1.0, "style": "Regular"])
let fc55 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.6, "style": "Regular"])
let fc54 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.8, "style": "Bold"])
let fp_s2 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.8, "style": "Bold"])
let fc32 = FontDetails.init(codingDict: ["color": "fafafa", "size": 12.0, "opacity": 0.4, "style": "Regular"])
let fc28 = FontDetails.init(codingDict: ["color": "fafafa", "size": 16.0, "opacity": 1.0, "style": "Regular"])
let fi3 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.6, "style": "Regular"])
let fc56 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.3, "style": "Regular"])
let fd5 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.8, "style": "Regular"])
let fC84 = FontDetails.init(codingDict: ["color": "ffffff", "size": 15.0, "opacity": 0.4, "style": "Regular"]) //  Switch On/Off Text
let fp_s5 = FontDetails.init(codingDict: ["color": "000000", "size": 15.0, "opacity": 0.8, "style": "Bold"]) // Post First Name
let fp_s6 = FontDetails.init(codingDict: ["color": "000000", "size": 15.0, "opacity": 0.6, "style": "Regular"]) // Posts Partner type
let fp_s7 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.4, "style": "Regular"]) // Posts timeStamp
let fp_s8 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 14.0, "opacity": 1.0, "style": "Bold"]) // posts HashTag UnRead
let fp_s9 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 14.0, "opacity": 1.0, "style": "Regular"])  // posts HashTag Read
let fp_s43 = FontDetails.init(codingDict: ["color": "359feb", "size": 12.0, "opacity": 1.0, "style": "Regular"]) // Posts hashtag count
let fp_s10 = FontDetails.init(codingDict: ["color": "000000", "size": 15.0, "opacity": 0.8, "style": "Bold"]) // Posts desc UnRead
let fp_s11 = FontDetails.init(codingDict: ["color": "000000", "size": 15.0, "opacity": 0.8, "style": "Regular"]) // Posts desc Read
let ff3 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.6, "style": "Medium"]) // Posts last activity
let ff4 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.4, "style": "Medium"]) // Posts comment Count
let fp_s15 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.8, "style": "Regular"]) // Posts summary Status default
let fp_s16 = FontDetails.init(codingDict: ["color": "ffffff", "size": 12.0, "opacity": 1.0, "style": "Regular"]) // Posts Summary status edited
let fp_s26 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Regular"])
let Fp_s14 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.4, "style": "Regular"])
let Fp_s31 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.4, "style": "Bold"]) // workspace count in post details
let fp_s45 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.8, "style": "Regular"])
let fp_s44 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.4, "style": "Regular"])
let fp_s31 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.4, "style": "Bold"])
let Fp_s32 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 16.0, "opacity": 1.0, "style": "Regular"]) // # Tags Text Color
let Fp_s29 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Bold"]) // # Post user Name Or Workspace Text Color
let Fp_s26 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Regular"]) //  post detail TextwithTag Cell normal text color
let Fp_s33 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 16.0, "opacity": 1.0, "style": "Regular"])  // URL color
let fp_s38 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.8, "style": "Regular"])  // URL color
let fp_s37 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.4, "style": "Regular"])  // attachment disabled color
let fp_s1 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.6, "style": "Regular"])  // Likes area
let ff38 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 14.0, "opacity": 1.0, "style": "Regular"]) // File No Authority SOP
let ff6 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.4, "style": "Regular"]) // File No Authority : File Name
let fc_d6 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.2, "style": "Regular"]) // File No Authority : File detail
let ff28 = FontDetails.init(codingDict: ["color": "ee8945", "size": 16.0, "opacity": 1.0, "style": "Regular"])
let ff39 = FontDetails.init(codingDict: ["color": "ee8945", "size": 16.0, "opacity": 0.5, "style": "Regular"])
let fc50 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.6, "style": "Regular"])
let fp1 = FontDetails.init(codingDict: ["color": "000000", "size": 20.0, "opacity": 0.8, "style": "Regular"])
let ff27 = FontDetails.init(codingDict: ["color": "8bc34a", "size": 16.0, "opacity": 1.0, "style": "Regular"])
let ff29 = FontDetails.init(codingDict: ["color": "ed4839", "size": 16.0, "opacity": 1.0, "style": "Regular"])
let ff31 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 16.0, "opacity": 0.8, "style": "Regular"])
let fp_s12 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.6, "style": "Regular"])
let btn_s4_normal = FontDetails.init(codingDict: ["color": "0e84dd", "size": 13.0, "opacity": 1.0, "style": "Regular"])
let btn_s4_pressed = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.2, "style": "Regular"])
let btn_s2_noneFont =  FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.4, "style": "Regular"])
let btn_s3_normal = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.8, "style": "Regular"])
let btn_s3_disable = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.2, "style": "Regular"])
let ff10 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 12.0, "opacity": 1.0, "style": "Regular"])
let fc21 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.8, "style": "Regular"])
let fp_s84 = FontDetails.init(codingDict: ["color": "000000", "size": 12.0, "opacity": 0.6, "style": "Bold"])
let fp2 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.6, "style": "Regular"])
let btn_normal4 = FontDetails.init(codingDict: ["color": "518cdb", "size": 16.0, "opacity": 1.0, "style": "Regular"])
let fc_37 = FontDetails.init(codingDict: ["color": "000000", "size": 11.0, "opacity": 0.5, "style": "Regular"]) // File No Authority : File detail
let copyRightColor = FontDetails.init(codingDict: ["color": "000000", "size": 11.0, "opacity": 0.6 , "style": "Regular"])
let versionDet = FontDetails.init(codingDict: ["color": "2a96fd", "size": 14.0, "opacity": 1.0 , "style": "Regular"])
let ff8 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8 , "style": "Regular"])
let screenLockPwd = FontDetails.init(codingDict: ["color": "000000", "size": 24.0, "opacity": 0.8, "style": "Regular"])
let screenLockError = FontDetails.init(codingDict: ["color": "ff3333", "size": 15.0, "opacity": 0.8, "style": "Regular"])
let screenLockPwdNumbers = FontDetails.init(codingDict: ["color": "000000", "size": 33.0, "opacity": 0.9, "style": "Medium"])

let fp_s30 = FontDetails.init(codingDict: ["color": "0e85dd", "size": 13.0, "opacity": 1.0, "style": "Regular"])

let btn_s2_PollNone = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.3, "style": "Regular"])
let btn_s2_PollVoted = FontDetails.init(codingDict: ["color": "359feb", "size": 13.0, "opacity": 0.1, "style": "Regular"])
let btn_s2_PollMost = FontDetails.init(codingDict: ["color": "f6b40e", "size": 13.0, "opacity": 1.0, "style": "Regular"])
let Fp_s34 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.6, "style": "Regular"])  // URL color
let fn2 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.4, "style": "Regular"])
let fr2 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.6, "style": "Regular"])
let fd2 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.8, "style": "Regular"])
let btn2_normal = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Regular"])
let fi1 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.8, "style": "Bold"])
let ff7 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.3, "style": "Regular"])
let profilePicLabel = FontDetails.init(codingDict: ["color": "fafafa", "size": 40.0, "opacity": 1.0, "style": "Regular"])
let profilePicLabelForSettings = FontDetails.init(codingDict: ["color": "fafafa", "size": 22.0, "opacity": 1.0, "style": "Regular"])
let btn_s1_normal = FontDetails.init(codingDict: ["color": "518cdb", "size": 15.0, "opacity": 1.0, "style": "Regular"])
let btn_s1_Disable = FontDetails.init(codingDict: ["color": "000000", "size": 15.0, "opacity": 0.8, "style": "Regular"])
let Fp_s41 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.6, "style": "Regular"])  // URL color
let fp_s49 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.4, "style": "Regular"])
let fp_s50 = FontDetails.init(codingDict: ["color": "000000", "size": 16.0, "opacity": 0.8, "style": "Regular"])
let Fp_s28 = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.6, "style": "Regular"]) //  post detail TextwithTag Cell normal text color
let fc_Search = FontDetails.init(codingDict: ["color": "fafafa", "size": 20.0, "opacity": 0.2, "style": "Regular"])
let fc_RecentSearch = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.8, "style": "Bold"])
let barColor = FontDetails.init(codingDict: ["color": "359feb", "size": 12.0, "opacity": 0.5, "style": "Regular"]) // Posts hashtag count
let bt1_normal = FontDetails.init(codingDict: ["color": "518cdb", "size": 14.0, "opacity": 1.0, "style": "Regular"])
let btn_NonPrimary = FontDetails.init(codingDict: ["color": "000000", "size": 13.0, "opacity": 0.8, "style": "Regular"])
let Fp_s68 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.9, "style": "Regular"])
let Fp_s36 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.4, "style": "Regular"])
let Fp_s35 = FontDetails.init(codingDict: ["color": "000000", "size": 14.0, "opacity": 0.8, "style": "Regular"])
