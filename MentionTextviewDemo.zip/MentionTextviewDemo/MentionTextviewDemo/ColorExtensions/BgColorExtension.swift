

import Foundation
import UIKit
struct ColorDetails {
    var color: UIColor
    init(codingDict: [String: Any]) {
        guard
            let color = codingDict["color"] as? String,
            let opacity = codingDict["opacity"] as? Double
            else {
                self.color = .white
                return
        }
        self.color = color.hexStringToUIColor(opacity: CGFloat(opacity))
    }
}

let bg4 = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 1.0])
let bg5 = ColorDetails.init(codingDict: ["color": "f2f2f2", "opacity": 1.0])
let bg16 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.7])
let bg46 = ColorDetails.init(codingDict: ["color": "f1f2f6", "opacity": 1.0])
let bg48 = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 1.0])
let bg45 = ColorDetails.init(codingDict: ["color": "3567b5", "opacity": 1.0])
let bgNoti = ColorDetails.init(codingDict: ["color": "fafafa", "opacity": 0.5])

let switchOff = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.4])
let switchOn = ColorDetails.init(codingDict: ["color": "359feb", "opacity": 0.4])
let bg28 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 1.0])
let line1 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.05]) // Menu section line
let line48 = ColorDetails.init(codingDict: ["color": "518cdb", "opacity": 1.0]) //Menu select line
let normalPostColor = ColorDetails.init(codingDict: ["color": "7fbbe8", "opacity": 1.0]) // normal Post color
let pollPostColor = ColorDetails.init(codingDict: ["color": "ffc636", "opacity": 1.0]) // normal Post color
let padPostColor = ColorDetails.init(codingDict: ["color": "a07aed", "opacity": 1.0]) // normal pad Post color
let todoPostColor = ColorDetails.init(codingDict: ["color": "40ba71", "opacity": 1.0]) // normal todo Post color
let unReadPostColor = ColorDetails.init(codingDict: ["color": "ff5253", "opacity": 1.0]) // unread post color
//let unReadPostColor = ColorDetails.init(codingDict: ["color": "ff5d5d", "opacity": 1.0]) // unread post color
let bg_s1 = ColorDetails.init(codingDict: ["color": "a07aed", "opacity": 0.08] ) // pad content summary background
let bg_s2 = ColorDetails.init(codingDict: ["color": "ffc636", "opacity": 0.1] ) // poll content summary background
let bg_s8 = ColorDetails.init(codingDict: ["color": "40ba71", "opacity": 0.08] ) // todo content summary background
let fileImageContainer = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.1] ) // file image icon background
let bg13 = ColorDetails.init(codingDict: ["color": "fafafa", "opacity": 1.0])
let bg14 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.2]) // List_Select
let bg15 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.3]) // List_Select
let Bg10 = ColorDetails.init(codingDict: ["color": "fffbe2", "opacity": 1.0]) // attachment cell
let bg53 = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.7] )  // N-day policy dim case
let bg52 = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 1.0] )  // N-day policy dim case
let Bg50 = ColorDetails.init(codingDict: ["color": ": ebf5fe", "opacity": 1.0]) // attachment cell

let dday_delay = ColorDetails.init(codingDict: ["color": "FD5457", "opacity": 0.6] )
let dday_edit = ColorDetails.init(codingDict: ["color": "0E85DD", "opacity": 0.4] )
let dday_fin = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.2] )
let dday_on = ColorDetails.init(codingDict: ["color": "85C640", "opacity": 0.6] )
let line45 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.14]) //Divider List_line
let btn_s4_radius_normal = ColorDetails.init(codingDict: ["color": "359feb", "opacity": 1.0])
let btn_s4_radius_selected = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.1])
// Feature/Sprint2/Post_Detail
let btn_post_detail_poll_ic_people = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.03])
let btn_post_detail_poll_ic_people_normal = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.08])
let poll_checkbox_off_bg = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.8])
let poll_checkbox_off_radius = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.32])
let poll_checkbox_on_bg = ColorDetails.init(codingDict: ["color": "359feb", "opacity": 1.0])
let poll_checkbox_disable_bg = ColorDetails.init(codingDict: ["color": "f2f2f2", "opacity": 1.0])
let poll_checkbox_disable_radius = ColorDetails.init(codingDict: ["color": "dddddd", "opacity": 1.0])
let btn_s3_radius_normal = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.8])
let btn_s3_radius_disable = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.8])
//Common colors used
let refreshControlColor = UIColor.init(red: 53/255, green: 103/255, blue: 181/255, alpha: 0.5)
// Feature/Sprint2/Develop
let view_RecipientBoxColor = ColorDetails.init(codingDict: ["color": "aaaaaa", "opacity": 0.8])
let hashTag_Bg = ColorDetails.init(codingDict: ["color": "deeaf2", "opacity": 1.0] )
let toDoInProgressProgressBarColor = ColorDetails.init(codingDict: ["color": "85c640", "opacity": 1.0])
let toDoDelayedProgressBarColor = ColorDetails.init(codingDict: ["color": "fd5457", "opacity": 1.0] )
let toDoCompletedProgressBarColor = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.37])
let line54 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.01])
let line21 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.1])
let line5 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.14])

let btn_s2_PollMost_Bg_Color = ColorDetails.init(codingDict: ["color": "ffc636", "opacity": 0.17])
// POLL CHECK BOX COLORS
let btn_Off = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.20])
let checkMark_Off = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.80])
let checkMark_Off_Stroke = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.32])
let btn_s2_none = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.30])

let checkMark_On = ColorDetails.init(codingDict: ["color": "359feb", "opacity": 1.00])

let checkMark_Disable = ColorDetails.init(codingDict: ["color": "f2f2f2", "opacity": 1.00])
let checkMark_Disable_Stroke = ColorDetails.init(codingDict: ["color": "000000", "opacity": 1.00])
let segmentControl = ColorDetails.init(codingDict: ["color": "3567B5", "opacity": 1.0])
let changeAssigneeBottomLine = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.04]) // Menu section line
let line39 = ColorDetails.init(codingDict: ["color": "000000", "opacity": 0.4])
let bg37 = ColorDetails.init(codingDict: ["color": "f6f6f6", "opacity": 1.0] )  // N-day policy dim case
let bg_padNav = ColorDetails.init(codingDict: ["color": "#a07aed", "opacity": 0.92] ) // pad content summary background

let pollBlue = ColorDetails.init(codingDict: ["color": "359feb", "opacity": 0.5])
let pollGray = ColorDetails.init(codingDict: ["color": "b2b2b2", "opacity": 0.5])
let pipeColor = ColorDetails.init(codingDict: ["color": "ffffff", "opacity": 0.2])

let primaryBtn = ColorDetails.init(codingDict: ["color": "359feb", "opacity": 1.0])
let bg_s6 = ColorDetails.init(codingDict: ["color": "f7fcff", "opacity": 1.0] )
