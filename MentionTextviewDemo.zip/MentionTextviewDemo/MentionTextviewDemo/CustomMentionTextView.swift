
import Foundation
import UIKit
import Atributika

enum WordType {
    case hashtag
    case mention
    case Url
}

class CustomMentionTextView: UITextView {
    
    var textString: NSString?
    var attrString: NSMutableAttributedString?
    var callBack: ((String, WordType) -> Void)?
    var rangeArray = [[String:Any]]()
    var wordsMentionHashtag = [String]()
    var mentionDetection = [Detection]()
    var hashtagDetection = [Detection]()
    var URLDetection = [Detection]()
    
    public func setText(text: NSMutableAttributedString, andMentionColor mentionColor: UIColor, font: UIFont, hashtagFont: UIFont, mentiontagFont: UIFont, strArray: [String], cursorPostion:Int, isback:@escaping ((String, WordType) -> Void)) {
        //self.callBack = isback
//        let attrString = NSMutableAttributedString(string: text.replacingOccurrences(of: "^", with: " "))
//        self.attrString = attrString
        self.attrString = text
//        let textString = NSString(string: text)
//        self.textString = textString
        self.textString = NSString(string: text.string)
        
        // Set initial font attributes for our string
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: NSRange(location: 0, length: (textString?.length)!))
        self.rangeArray = []
        // Call a custom set Hashtag and Mention Attributes Function
        verifyUrl(urlString: textString! as String, attrName: "Url", wordPrefix: "", color: Fp_s33.color, font: Fp_s33.font)
        setAttrWithName(attrName: "Hashtag", wordPrefix: "#", color: Fp_s32.color, text: textString! as String, font: hashtagFont)
        setAttrWithName(attrName: "Mention", wordPrefix: "@", color: mentionColor, text: textString! as String, font: mentiontagFont)
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
//        if !isback{
//            let arbitraryValue: Int = cursorPostion
//            if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
//                self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
//            }
//        }
//        else{
//            if(cursorPostion < text.length){
//                let arbitraryValue: Int = cursorPostion
//                if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
//                    self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
//                }
//            }
//        }
       
//         Add tap gesture that calls a function tapRecognized when tapped
//                let tapper = UITapGestureRecognizer(target: self, action: #selector(tapRecognized))
//                //let tapper = UITapGestureRecognizer(target: self, action: Selector("tapRecognized:"))
//                addGestureRecognizer(tapper)
    }
    
    
    public func setTextNew(text: [PostContentType], andMentionColor mentionColor: UIColor, font: UIFont, hashtagFont: UIFont, mentiontagFont: UIFont, strArray: [String], cursorPostion:Int) {
        var normalText = ""
        for i in text{
            normalText += i.value!
        }
        self.attrString = NSMutableAttributedString(string: normalText)
        self.textString = NSString(string: normalText)
        // Set initial font attributes for our string
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: NSRange(location: 0, length: (textString?.length)!))
        self.rangeArray = []
        // Call a custom set Hashtag and Mention Attributes Function
        verifyUrlNew(attrName: text, type: TYPE.HREF, color: Fp_s33.color, text: textString! as String, font: Fp_s33.font)
            //verifyUrl(urlString: textString! as String, attrName: "Url", wordPrefix: "", color: Fp_s33.color, font: Fp_s33.font)
        setAttrWithNameNew(attrName: text, type: TYPE.HASHTAG, color: Fp_s32.color, text: textString! as String, font: hashtagFont)
            // setAttrWithName(attrName: "Hashtag", wordPrefix: "#", color: Fp_s32.color, text: textString! as String, font: hashtagFont)
        setAttrWithNameNew(attrName: text, type: TYPE.MENTION, color: mentionColor, text: textString! as String, font: mentiontagFont)
            //setAttrWithName(attrName: "Mention", wordPrefix: "@", color: mentionColor, text: textString! as String, font: mentiontagFont)
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
    }
    
    func verifyUrlNew (attrName: [PostContentType], type: TYPE, color: UIColor, text: String, font:UIFont) {
        var finalRange = NSRange(location: 0, length: NSString(string: text).length)
        for word in attrName.filter({$0.type == type}) {
            if canOpenURL(string: word.value?.trimmingCharacters(in: .whitespaces)){
                let range = textString?.range(of: word.value!, options: [], range: finalRange)
                    attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey(rawValue: word.value!), value: 1, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey(rawValue: "URL"), value: word.value!, range: range!)
                    finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: NSString(string: text).length - ((range?.location)! + (range?.length)!))
                }
                self.attributedText = attrString
            
        }
    }
    
    func verifyUrl (urlString: String,attrName: String, wordPrefix: String, color: UIColor, font:UIFont) {
//        var words = urlString.components(separatedBy: " ")
//        for i in 0...words.count-1{
//            if words[i].contains("\n"){
//                let innerwords = words[i].components(separatedBy: "\n")
//                for k in 0...innerwords.count-1{
//                    if k==0{
//                        words[i] = innerwords[k]
//                    } else{
//                        words.insert(innerwords[k], at: i+k)
//                    }
//                }
//            }
//        }
        self.wordsMentionHashtag = urlString.components(separatedBy: " ")
        self.recursiveTempArrayCreation()
        var finalRange = NSRange(location: 0, length: urlString.count)
        for word in self.wordsMentionHashtag {
            // create NSURL instance
            if let url = NSURL(string: word.trimmingCharacters(in: .whitespaces)) {
                // check if your application can open the NSURL instance
                if canOpenURL(string: word.trimmingCharacters(in: .whitespaces)){
                    let range = textString?.range(of: word, options: [], range: finalRange)
                    attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey(rawValue: attrName), value: 1, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey(rawValue: "Clickable"), value: 1, range: range!)
                    attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: range!)
                    finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: urlString.count - ((range?.location)! + (range?.length)!))
                }
                self.attributedText = attrString
            }
            
        }
    }
    
    func canOpenURL(string: String?) -> Bool {
        let regExOne = "(^(?:www\\.)|^(?:m\\.))[a-zA-Z0-9@:%._\\+~#=]{2,256}"
        let regEx = "^(http(s)?):\\/\\/[a-zA-Z0-9@:%._\\+~#=]{2,256}"
        let predicate = NSPredicate(format:"SELF MATCHES %@", argumentArray:[regExOne])
        if predicate.evaluate(with: string!.lowercased()){
            return true
        }
        let predicatehttp = NSPredicate(format:"SELF MATCHES %@", argumentArray:[regEx])
        if predicatehttp.evaluate(with: string!.lowercased()){
            return true
        }
        return false
    }
    
    func setAttrWithNameNew(attrName: [PostContentType], type: TYPE, color: UIColor, text: String, font:UIFont) {
        
        var finalRange = NSRange(location: 0, length: NSString(string: text).length)
        for word in attrName.filter({$0.type == type}) {
            let range = textString?.range(of: word.value!, options: [], range: finalRange)
            //            let range = textString!.range(of: word)
            //self.rangeArray.append(range!)
            attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: range!)
            attrString?.addAttribute(NSAttributedStringKey(rawValue: word.value!), value: 1, range: range!)
            attrString?.addAttribute(NSAttributedStringKey(rawValue: "Clickable"), value: 1, range: range!)
            if type == .MENTION{
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "mention"), value: word.value!, range: range!)
                self.rangeArray.append(["type":"mention","range":range!])
            } else{
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "hashtag"), value: word.value!, range: range!)
                self.rangeArray.append(["type":"hashtag","range":range!])
            }
            attrString?.addAttribute(NSAttributedStringKey(rawValue: "range"), value: range!, range: range!)
            attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: range!)
            finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: NSString(string: text).length - ((range?.location)! + (range?.length)!))
        }
        self.attributedText = attrString
        print(self.rangeArray)
    }
    
    func setAttrWithName(attrName: String, wordPrefix: String, color: UIColor, text: String, font:UIFont) {
//         let wm = text.replacingOccurrences(of: "\n", with: " ")
//        let words = wm.components(separatedBy: " ")
//         let words = attrName.componentsSeparatedByString(" ")
        
        self.wordsMentionHashtag = text.components(separatedBy: " ")
        self.recursiveTempArrayCreation()
//        for i in 0...words.count-1{
//            if words[i].contains("\n"){
//                let innerwords = words[i].components(separatedBy: "\n")
//                for k in 0...innerwords.count-1{
//                    if k==0{
//                       words[i] = innerwords[k]
//                    } else{
//                       words.insert(innerwords[k], at: i+k)
//                    }
//                }
//            }
//        }
        var finalRange = NSRange(location: 0, length: text.count)
        for word in self.wordsMentionHashtag.filter({$0.hasPrefix(wordPrefix)}) {
            let range = textString?.range(of: word, options: [], range: finalRange)
//            let range = textString!.range(of: word)
            //self.rangeArray.append(range!)
            attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: range!)
            attrString?.addAttribute(NSAttributedStringKey(rawValue: attrName), value: 1, range: range!)
            attrString?.addAttribute(NSAttributedStringKey(rawValue: "Clickable"), value: 1, range: range!)
            attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: range!)
            finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: text.count - ((range?.location)! + (range?.length)!))
        }
        self.attributedText = attrString
        print(self.rangeArray)
    }
    func setAttrWithWordMention(word:NSMutableAttributedString,range:NSRange, color: UIColor, text: String, font:UIFont, attrName:String, cursorPostion:Int) {
        self.attrString = word
        let ranging = NSRange(location: range.location, length: NSString(string: attrName).length)
        //self.rangeArray.append(ranging)
        self.rangeArray.append(["type":"mention","range":ranging])
        attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey(rawValue: "mention"), value: attrName, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: ranging)
        self.attributedText = attrString
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
        print(self.rangeArray)
    }
    
    func setAttrWithWordHashtag(word:NSMutableAttributedString,range:NSRange, color: UIColor, text: String, font:UIFont, attrName:String, cursorPostion:Int) {
        self.attrString = word
        self.textString = NSString(string: word.string)
        let ranging = NSRange(location: range.location, length: NSString(string: attrName).length)
        //self.rangeArray.append(ranging)
//        for i in 0...self.rangeArray.count-1 where (range.location+1) == (self.rangeArray[i]["range"] as? NSRange)!.location{
//            self.rangeArray.remove(at: i)
//        }
        self.rangeArray.append(["type":"hashtag","range":ranging])
        attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey(rawValue: "hashtag"), value: attrName, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: ranging)
        self.attributedText = attrString
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
        print(self.rangeArray)
    }
    
    func setAttrWithWordURL(word:NSMutableAttributedString,range:NSRange, color: UIColor, text: String, font:UIFont, attrName:String, cursorPostion:Int) {
        self.attrString = word
        self.textString = NSString(string: word.string)
        let ranging = NSRange(location: range.location, length: NSString(string: attrName).length)
        //self.rangeArray.append(ranging)
        self.rangeArray.append(["type":"URL","range":ranging])
        attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: color, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey(rawValue: "URL"), value: attrName, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: ranging)
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: ranging)
        self.attributedText = attrString
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
        print(self.rangeArray)
    }
    func hashtagRecursion(finalRangee:NSRange,texttemp:String)  {
        var finalRange = finalRangee
        for i in self.hashtagDetection{
            let wordtemp = i.style.typedAttributes.values.first![NSAttributedStringKey(rawValue: "hashtag")]
            let str = wordtemp as? String ?? " "
            if textString?.range(of: str, options: [], range: finalRange).location == NSNotFound{
                
            } else{
                let range = textString?.range(of: str, options: [], range: finalRange)
                //            let range = textString!.range(of: word)
                if range?.location != 0 && (textString?.substring(to: (range?.location)!).last != " " || textString?.substring(to: (range?.location)!).last != "\n"){
                    if textString?.substring(to: (range?.location)!).last == "\n"{
                        
                    } else if textString?.substring(to: (range?.location)!).last == " "{
                        
                    } else{
                        finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: NSString(string: texttemp).length - ((range?.location)! + (range?.length)!))
                        hashtagRecursion(finalRangee: finalRange, texttemp: texttemp)
                        return
                    }
                }
                //self.rangeArray.append(range!)
                self.rangeArray.append(["type":"hashtag","range":range!])
                attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: Fp_s32.color, range: range!)
                attrString?.addAttribute(NSAttributedStringKey.font, value: Fp_s32.font, range: range!)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "hashtag"), value: str, range: range!)
                finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: NSString(string: texttemp).length - ((range?.location)! + (range?.length)!))
            }
        }
    }
    
    func convertingToNsRange(txt:String,range:NSRange) -> NSRange {
        // Compute String.UnicodeScalarView indices for first and last position:
        let fromIdx = txt.unicodeScalars.index(txt.unicodeScalars.startIndex, offsetBy: range.location)
        let toIdx = txt.unicodeScalars.index(fromIdx, offsetBy: range.length)
        // Compute corresponding NSRange:
        let nsRange = NSRange(fromIdx..<toIdx, in: txt)
        return nsRange
    }
    
    func setAttrWithoutSpace(word:NSMutableAttributedString, text: String, font:UIFont, cursorPostion:Int) {
        
        self.attrString = word
        self.textString = NSString(string: text)
        var finalRange = NSRange(location: 0, length: self.textString!.length)
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: NSRange(location: 0, length: (textString?.length)!))
        self.rangeArray = []
        for i in self.mentionDetection{
            let wordtemp = i.style.typedAttributes.values.first![NSAttributedStringKey(rawValue: "mention")]
            let str = wordtemp as? String ?? " "
            print(wordtemp as? String ?? " ")
            if textString?.range(of: str, options: [], range: finalRange).location == NSNotFound{
                
            } else{
                //let rangeing = textString?.range(of: str, options: [], range: finalRange)
                let range = textString?.range(of: str, options: [], range: finalRange)
                //            let range = textString!.range(of: word)
                //self.rangeArray.append(range!)
                self.rangeArray.append(["type":"mention","range":range!])
                attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: Fp_s29.color, range: range!)
                attrString?.addAttribute(NSAttributedStringKey.font, value: Fp_s29.font, range: range!)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "mention"), value: str, range: range!)
                finalRange = NSRange(location: (range!.location) + (range!.length), length: NSString(string: text).length - ((range!.location) + (range!.length)))
            }
        }
        finalRange = NSRange(location: 0, length: self.textString!.length)
//        for i in self.hashtagDetection{
//            let wordtemp = i.style.typedAttributes.values.first![NSAttributedStringKey(rawValue: "hashtag")]
//            let str = wordtemp as? String ?? " "
//            if textString?.range(of: str, options: [], range: finalRange).location == NSNotFound{
//
//            } else{
//                let range = textString?.range(of: str, options: [], range: finalRange)
//                //            let range = textString!.range(of: word)
////                if range?.location != 0 && (textString?.substring(to: (range?.location)!).last != " " || textString?.substring(to: (range?.location)!).last != "\n"){
////                    finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: text.count - ((range?.location)! + (range?.length)!))
////                    continue
////                }
//                self.rangeArray.append(range!)
//                attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: Fp_s32.color, range: range!)
//                attrString?.addAttribute(NSAttributedStringKey.font, value: Fp_s32.font, range: range!)
//                attrString?.addAttribute(NSAttributedStringKey(rawValue: "hashtag"), value: str, range: range!)
//                finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: text.count - ((range?.location)! + (range?.length)!))
//            }
//        }
        self.hashtagRecursion(finalRangee: finalRange, texttemp: text)
        finalRange = NSRange(location: 0, length: self.textString!.length)
        for i in self.URLDetection{
            let wordtemp = i.style.typedAttributes.values.first![NSAttributedStringKey(rawValue: "URL")]
            let str = wordtemp as? String ?? " "
            if textString?.range(of: str, options: [], range: finalRange).location == NSNotFound{
                
            } else{
                let range = textString?.range(of: str, options: [], range: finalRange)
                //            let range = textString!.range(of: word)
                //self.rangeArray.append(range!)
                self.rangeArray.append(["type":"URL","range":range!])
                attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: Fp_s33.color, range: range!)
                attrString?.addAttribute(NSAttributedStringKey.font, value: Fp_s33.font, range: range!)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "URL"), value: str, range: range!)
                attrString?.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: range!)
                finalRange = NSRange(location: (range?.location)! + (range?.length)!, length: NSString(string: text).length - ((range?.location)! + (range?.length)!))
            }
        }
        self.attributedText = attrString
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
    }
    
    func setAttriForSpace(word:NSMutableAttributedString,font:UIFont, color: UIColor, text: String, mentionColor: UIColor, mentionFont: UIFont, cursorPostion:Int) {
        self.attrString = word
        self.textString = NSString(string: word.string)
        var finalRange = NSRange(location: 0, length: text.count)
        attrString?.addAttribute(NSAttributedStringKey.font, value: font, range: NSRange(location: 0, length: (textString?.length)!))
        self.wordsMentionHashtag = text.components(separatedBy: " ")
        for wordtemp in self.wordsMentionHashtag where !wordtemp.isEmpty{
            let str = text as NSString
            let range = str.range(of: wordtemp, options: [], range: finalRange)
            //let range = text.range(of: wordtemp, options: [], range: Range(finalRange, in: text))
            //WORKING ON MENTION ATTRIBUTED TEXT
            if (rangeArray.count)>0{
                for i in 0...(rangeArray.count)-1 where (rangeArray[i]["range"] as? NSRange)?.location == range.location{
                    let temp = text.substring(from: (rangeArray[i]["range"] as? NSRange)?.location, to: (rangeArray[i]["range"] as? NSRange)?.length)
                    attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: mentionColor, range: (rangeArray[i]["range"] as? NSRange)!)
                    attrString?.addAttribute(NSAttributedStringKey(rawValue: temp), value: 1, range: (rangeArray[i]["range"] as? NSRange)!)
                    attrString?.addAttribute(NSAttributedStringKey(rawValue: "Clickable"), value: 1, range: (rangeArray[i]["range"] as? NSRange)!)
                    attrString?.addAttribute(NSAttributedStringKey.font, value: mentionFont, range: (rangeArray[i]["range"] as? NSRange)!)
                }
            }
            //WORKING ON HASHTAG ATTRIBUTED TEXT
            if wordtemp.hasPrefix("#"){
                attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: Fp_s32.color, range: range)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: wordtemp), value: 1, range: range)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "Clickable"), value: 1, range: range)
                attrString?.addAttribute(NSAttributedStringKey.font, value: Fp_s32.font, range: range)
            }
            //WORKING ON URL ATTRIBUTED TEXT
            if canOpenURL(string: wordtemp.trimmingCharacters(in: .whitespaces)){
                attrString?.addAttribute(NSAttributedStringKey.foregroundColor, value: Fp_s33.color, range: range)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: wordtemp), value: 1, range: range)
                attrString?.addAttribute(NSAttributedStringKey.underlineStyle, value: NSUnderlineStyle.styleSingle.rawValue, range: range)
                attrString?.addAttribute(NSAttributedStringKey(rawValue: "Clickable"), value: 1, range: range)
                attrString?.addAttribute(NSAttributedStringKey.font, value: Fp_s33.font, range: range)
            }
            finalRange = NSRange(location: (range.location) + (range.length), length: text.count - ((range.location) + (range.length)))
        }
        self.attributedText = attrString
        let arbitraryValue: Int = cursorPostion
        if let newPosition = self.position(from: self.beginningOfDocument, offset: arbitraryValue) {
            self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
        }
    }
    
    func recursiveTempArrayCreation() {
        let count = self.wordsMentionHashtag.count
        for i in 0...self.wordsMentionHashtag.count-1{
            if self.wordsMentionHashtag[i].contains("\n"){
                let innerwords = self.wordsMentionHashtag[i].components(separatedBy: "\n")
                for k in 0...innerwords.count-1{
                    if k==0{
                        self.wordsMentionHashtag[i] = innerwords[k]
                    } else{
                        self.wordsMentionHashtag.insert(innerwords[k], at: i+k)
                    }
                }
            }
        }
        if count<self.wordsMentionHashtag.count{
            self.recursiveTempArrayCreation()
        }
    }
    
}
