
import UIKit

struct PostContentType {
    var value: String?
    var id: String?
    var type: TYPE?
}
enum TYPE {
    case MENTION
    case HREF
    case TEXT
    case HASHTAG
}

class ViewController: UIViewController, UITextViewDelegate{

    var textviewEditMode: CustomMentionTextView?
    @IBOutlet weak var tblSuggestionMention: UITableView!
    var mentionOptions = ["Dhairya Uniyal","Mani Singh","새 업무그룹 2","Sunil","Pankaj Kumar Dwivedi"]
    var searchString = ""
    var insertionIndex:Int = -1
    var nameSelectionClosure: (String) -> (Void) = {_ in}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.setupUI()
    }
    func setupUI() {
        textviewEditMode = CustomMentionTextView(frame: CGRect(x: 10.0, y: 120.0, width: self.view.frame.width-20, height: 180.0))
        textviewEditMode?.isScrollEnabled = true
        textviewEditMode?.isEditable = true
        textviewEditMode?.delegate = self
        textviewEditMode?.backgroundColor = UIColor.lightGray
        textviewEditMode?.autocorrectionType = .no
        view.addSubview(textviewEditMode!)
        textviewEditMode?.becomeFirstResponder()
        
        tblSuggestionMention.frame = CGRect(x: 10.0, y: 301.0, width: (textviewEditMode?.frame.width)!, height: 160.0)
        tblSuggestionMention.layer.borderWidth = 0.5
        tblSuggestionMention.layer.borderColor = #colorLiteral(red: 0.7215686275, green: 0.7215686275, blue: 0.7215686275, alpha: 1)
        tblSuggestionMention.isHidden = true
        
        tblSuggestionMention.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    
    //detecting attributed ranges of strings in complete textview's text
    func checking() {
        //taking mention out of attributed string
        let attArray = self.textviewEditMode?.attributedText.styleMentions(.backgroundColor(Fp_s29.color))
        let detections = attArray?.detections
        let mentionsArray = detections?.filter({($0.style.typedAttributes.values.first?.keys.contains(NSAttributedStringKey(rawValue: "mention")))!})
        print(mentionsArray!)
        
        //taking hashtags out of attributed string
        let attHashtagArray = self.textviewEditMode?.attributedText.styleMentions(.backgroundColor(Fp_s32.color))
        let detectionsHashtags = attHashtagArray?.detections
        let hashtagArray = detectionsHashtags?.filter({($0.style.typedAttributes.values.first?.keys.contains(NSAttributedStringKey(rawValue: "hashtag")))!})
        print(hashtagArray!)
        
        //taking URL out of attributed string
        let attURLArray = self.textviewEditMode?.attributedText.styleMentions(.backgroundColor(Fp_s33.color))
        let detectionsURL = attURLArray?.detections
        let URLArray = detectionsURL?.filter({($0.style.typedAttributes.values.first?.keys.contains(NSAttributedStringKey(rawValue: "URL")))!})
        print(URLArray!)
        
        self.textviewEditMode?.mentionDetection = mentionsArray!
        self.textviewEditMode?.hashtagDetection = hashtagArray!
        self.textviewEditMode?.URLDetection = URLArray!
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let currentText = textView.text as NSString
        let updatedText = currentText.replacingCharacters(in: range, with: text) as NSString
        self.checking()
        let mutableStr = NSMutableAttributedString(string: String(currentText))
        textviewEditMode?.setAttrWithoutSpace(word: mutableStr, text: String(currentText), font: Fp_s26.font, cursorPostion: getCurrentCursorPostion())
        //handling backspace for mention hashtag and url
        //let  char = text.cString(using: String.Encoding.utf8)!
        //let isBackSpace = strcmp(char, "\\b")
        // handling backspace
        if text == "@"{
            let curCursor = getCurrentCursorPostion()
            if curCursor == 0{
                searchString = "@"
                self.insertionIndex = getCurrentCursorPostion()
            } else if text == "@" && (updatedText.substring(to: getCurrentCursorPostion()).last! == " " || updatedText.substring(to: getCurrentCursorPostion()).last! == "\n"){
                searchString = "@"
                self.insertionIndex = getCurrentCursorPostion()
            }
            self.tblSuggestionMention.isHidden = false
        }
        if text != " " && text != "\n" && self.insertionIndex == -1{
            self.searchString += text
        }
        if text != " " && text != "\n" && self.insertionIndex != -1{
            searchString += text
            if searchString.first == "@" && searchString.count>1{
                searchString = String(searchString.dropFirst())
            }
            self.nameSelectionClosure = {returnedString in
                if self.insertionIndex == -1{
                    self.tblSuggestionMention.isHidden = true
                } else{
                    let finalRange = NSRange(location: self.insertionIndex, length: NSString(string: (self.textviewEditMode?.text)!).length-self.insertionIndex)
                    let str = self.textviewEditMode?.textString?.substring(with: NSRange(location: self.insertionIndex, length: self.getCurrentCursorPostion()-self.insertionIndex))
                    let rangeNew:NSRange?
                    if str == "@"{
                        //rangeNew = self.convertingToNsRange(txt: String(self.searchString), range: finalRange)
                        //rangeNew = updatedText.range(of: self.searchString, options: [], range: finalRange)
                        rangeNew = NSString(string: (self.textviewEditMode?.text)!).range(of: str!, options: [], range: finalRange)
                    } else{
                        //rangeNew = self.convertingToNsRange(txt: String(self.searchString), range: finalRange)
                        rangeNew = NSString(string: (self.textviewEditMode?.text)!).range(of: str!, options: [], range: finalRange)
                    }
                    if rangeNew?.location == NSNotFound{
                        self.tblSuggestionMention.isHidden = true
                        self.searchString = ""
                    } else{
                        //self.setTextTemp(str: totalMuatble)
                        let totalAttrStr = self.textviewEditMode?.attributedText
                        let totalMuatble:NSMutableAttributedString = NSMutableAttributedString.init(attributedString: totalAttrStr!)
                        totalMuatble.replaceCharacters(in: rangeNew!, with: returnedString+" ")
                        self.textviewEditMode?.setAttrWithWordMention(word: totalMuatble, range: rangeNew!, color: Fp_s29.color, text: returnedString, font: Fp_s29.font, attrName: returnedString, cursorPostion: self.getCurrentCursorPostion())
                        self.tblSuggestionMention.isHidden = true
                        self.setCurrentCursorPosition(cursorPostion: self.insertionIndex+returnedString.count+1)
                        self.searchString = ""
                        // self.insertionIndex = -1
                        self.checking()
                        self.textviewEditMode?.setAttrWithoutSpace(word: totalMuatble, text: totalMuatble.string, font: Fp_s26.font, cursorPostion: self.insertionIndex+returnedString.count+1)
                        self.insertionIndex = -1
                    }
                }
            }
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        self.checking()
        let mutableStr = NSMutableAttributedString(string: String(textView.text))
        textviewEditMode?.setAttrWithoutSpace(word: mutableStr, text: String(textView.text), font: Fp_s26.font, cursorPostion: getCurrentCursorPostion())
    }
    
    func getCurrentCursorPostion() -> Int {
        if let selectedRange = textviewEditMode?.selectedTextRange {
            let cursorPosition = textviewEditMode?.offset(from: (textviewEditMode?.beginningOfDocument)!, to: selectedRange.start)
            //print("\(cursorPosition!)")
            return cursorPosition!
        }
        return 0
    }
    
    func setCurrentCursorPosition(cursorPostion:Int) {
        let arbitraryValue: Int = cursorPostion
        if let newPosition = textviewEditMode?.position(from: (textviewEditMode?.beginningOfDocument)!, offset: arbitraryValue) {
            textviewEditMode?.selectedTextRange = textviewEditMode?.textRange(from: newPosition, to: newPosition)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.mentionOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        cell.textLabel?.text = self.mentionOptions[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 68.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.nameSelectionClosure(self.mentionOptions[indexPath.row])
    }
}

extension String{
    func hexStringToUIColor (opacity: CGFloat) -> UIColor {
        var cString: String = self.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue: UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: opacity
        )
    }
    
    func substring(from: Int?, to: Int?) -> String {
        if let start = from {
            guard start < self.characters.count else {
                return ""
            }
        }
        
        if let end = to {
            guard end >= 0 else {
                return ""
            }
        }
        
        if let start = from, let end = to {
            guard end - start >= 0 else {
                return ""
            }
        }
        
        let startIndex: String.Index
        if let start = from, start >= 0 {
            startIndex = self.index(self.startIndex, offsetBy: start)
        } else {
            startIndex = self.startIndex
        }
        
        let endIndex: String.Index
        if let end = to, end >= 0, end < self.characters.count {
            endIndex = self.index(self.startIndex, offsetBy: end)
        } else {
            endIndex = self.endIndex
        }
        
        return String(self[startIndex ..< endIndex])
    }
}
